public class NoShape1 extends Shape implements ShapeFields {
    static int [][] coords = { { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 } };    
}
