public class SquareShape1 extends Shape implements ShapeFields {
    static int[][] coords = { { 0, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 } };
    
}
