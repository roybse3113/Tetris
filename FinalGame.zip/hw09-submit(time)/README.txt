=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: 29349395
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

OVERALL FUNCTIONALITY OF GUI:

The GUI consists of the game playing area in the center, a status panel at the bottom, 
and a control panel at the top. 

Control Panel: The control panel consists of the score, which should start at 0 and update
as one plays, and the menu for instructions.

Status Panel: The status panel consists of the enter, start, and restart button. Upon running
the game for the first time, a player cannot press start or restart as it pops an error
about the need to enter a user name first. So, in order to play properly, one must:
 
  1. Type a user name in the text box provided. There is already the text "username" which 
  can be used or replaced. The username must not be empty and cannot contain white spaces. 
  Once a user name is typed, press "enter".
  
  2. Once the user name is entered without an error message, press "start". Pieces should
  start dropping from the board. The player can then play
  
  3. After having pressed start, the player cannot press enter or start as it would prevent
  the player from continuing to play. The player, while the game has started, can only press 
  restart to reset the board. Otherwise, the player must play until the the "game over" message 
  is updated on the bottom of the screen in place of the score. Once the game is over, if there
  are three ore more players, the high scores should appear. At this point, the player can then again 
  enter a new user name or the use the same. 

- List the four core concepts, the features they implement, and why each feature
  is an appropriate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. 2D Arrays:
  
  2D arrays are appropriate from my game because I needed to store the coordinates
  of each shape to properly draw the shape in the first place. Then, these coordinates
  are used by the Shape and each individual shape class to keep track and update the 
  coordinates the 2D arrays to move and rotate each piece. 

  2. I/O
  
  I/O was used to keep track of the states of the user name and password. First, the user name
  was inputted into the Game.java in order to play the game. The user name is stored into a 
  TreeMap in which it is the key and the value is a score that is updated in Board.java. In this 
  class, as the board keeps track of where the shapes in an array of Tetrominoes that span the area
  of the board, the score increases with each full line. This score then is updated once the game 
  is over. With the updated scores, the scores are sorted in a descending order. Once this is done,
  the user names are sorted accordingly with the scores so as to properly update the high scores.

  3. Inheritance/Sub-typing
  
  The ShapeFields interface is responsible for storing the methods for setting and getting the X and Y 
  coordinates of each shape from the 2D array of coordinates, getting and setting the shape of the current
  piece, setting the count of the current shape's orientation/turn, setting a random shape for the next
  piece, and rotating left. This class overrides the rotateLeft method so as to check for shapes and
  implement the different rotateLeft implementations in each of the different shapes. These functionalities 
  are the implemented in the Shape class in order to properly store and update the coordinates of the 2D array. 
  This allows for proper repainting of the shapes. The individual shape classes also implement the rotateLeft() 
  method so as to override and implement it in a way that adjusts to the coordinates of each different piece. Each 
  of these shape classes also extend the Shape class as a way to inherit the proper coordinates and current shape
  of the piece to properly adjust the rotating method.

  4. Testable Component
  
  The testable component is responsible for testing the state of the game. The main aspects to test are the conditions 
  and edge cases for each shape. When the pieces are at the edge or at the bottom of the board, the tests make sure that 
  they cannot move down, move horizontally, or rotate once these positions are reached. The tests also test to see that
  the game starts and resets properly in a way of clearing the board an resetting the score. 

=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.

	1. Board.java:
	
	This class is responsible for intializing and setting up the board or
	playing area. It includes the height and width of the board, the timer 
	to adjust the falling pieces, the starting and stopping state of the game,
	the current coordinates of the piece, and the statusBar so as to update the score
	when appropriate. The board is also responsible for implementing the methods for 
	moving one line down, moving all the way down, moving left and right, clearing full
	lines, and more. This class also contains the I/O for user names and player scores
	as a way to add scores accordingly with the key of a user name and sorting them so
	as to properly display the high scores when there are 3 players. The I/O is responsible
	for keeping track of the usernames of the players when inputting from Game.java
	and the scores that are updated with each line that is full and clear when playing the game.
	The scores update once the current game is over. 
	
	2. Game.java:
	
	This class is responsible for specifying the widgets and frame of the GUI. 
	It contains the runnable component and puts together the layout of the game,
	the buttons and their functionality, and the game overall. It includes the 
	status bar, menu, start button, and etc to allow for user name input, for 
	game start, restart, menu, and etc. For instance, the restart button
	allows for players to restart even after pressing start if they want a different 
	starting piece or messed up placements. It also contains the file writer for
	user names onto Scores.txt. It primarily functions to store the user names
	into the players Tree Map that stores all user names and scores. This is 
	then used in Board.java to update the score and properly sort the highest
	scores.
	
	3. Shape.java:
	
	This class implements the methods from the ShapeFields interface. This includes 
    methods such as setting the X and Y coordinates, setting the count to keep track 
    of which turn a shape is on, getting the shape of the current piece, and 
    turning to the left (the only rotation provided in this game). In particular this
    class overrides the rotateLeft method in order to properly check for shape and 
    rotate accordingly. The Shape class keeps track of the coordinates of each piece, 
    properly setting and getting the x and y values in order to rotate the piece. The
    Shape class also includes the setRandomShape method which is responsible for providing 
    the next pieces to drop on the board once the previous pieces have been used. In specific
    the coordinates of the pieces are stored in a double array to properly draw each shape
    on a 2D surface and adjust when rotated or moved.
	
	4. ShapeFields.java:
	
	This is the interface that is implemented in Shape.java and each the different shape
	classes. This interface includes methods such as getting and setting the shape of the piece to 
	a different one, getting and setting the X and Y coordinates, setting the current count
	of which turn to execute, preparing the next piece by setting a random shape, and rotating
	the piece to the left. 
	
	5. Tetrominoes.java:
	
	This is the enum that stores all the different values or possible shapes of the tetrominoes.
	Each shape takes parameters of the coordinates and the random color that is chosen by colorChoose().
	This method is implemented within the enum as a way to randomly select a color for each time that
	the game starts.
	
	6. GameTest.java:
	
	The GameTest file was responsible for the testable component of the game. It tested the game state
	for aspects such as the where the shapes can or cannot rotate or move. It tested the functioning of 
	the updated start or reset state to clear the board. It tested for the proper functionality of 
	removing lines when they were full (and updating the score accordingly), the updating of coordinates
	when rotating a shape, and etc. 
	
All Shape Implementations
	
	7-13. LineShape1.java, LShape1.java, MirroredLShape.java, NoShape1.java, SShape1.java,
	TShape1.java, ZShape1.java:
	
	Each of these classes for the different possible shapes implemented the rotateLeft() method
	from ShapeFields. This rotate method was overrode to properly implement and update the coordinates
	of each different shape for when it turned each time. It utilized a count that was kept track 
	in Shape.java to determine which turn is being executed. These classes were also responsible for 
	initalizing the shape coordinates updating the coordinates of each piece in Shape.java when 
	rotating.
	
- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?
  
  While making my game, I often ran into issues with the scope of some variables. For instance,
  I would have already made the coordinates of the Shape class or the current coordinates in 
  the Board class to be private where I actually needed it in other classes to implement properly.
  I also spent some time trying to figure out how to properly sort the user names by scores. I had 
  stored the user names as keys in a TreeMap and the scores as values, so I had to take some time to 
  figure out how to sort the collections with each score and update the score board with user names
  as well. As for my design, I had the some difficulty in organizing the inheritance/sub typing of the
  classes. My plan was to create Shape.java as an abstract class that would be extended from each of the
  different shape classes. This way, each shape would be able to properly override the rotateLeft() method
  and not have to check for each shape when implementing the method in the Shape class. Though,
  I had designed it in a way that I had created new instance of shapes when implementing the rotateLeft
  method for each class so as to return a result shape that would be updated with the proper coordinates.


- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you re factor, if given the chance?

  The separation of functionality is sufficient. I separated the board, game, shape, tetrominoes, and 
  classes for each different shape to allow for a distinction of functionality. The board was responsible
  for movement, dropping pieces, clearing lines, preparing the nextPiece, the timing of the falling pieces,
  and updating the high scores once the current player's game was over. The game class was responsible
  for setting up the frame and widgets of the game so as to implement the playing field with the ability 
  to input a user name, update the score at the bottom, start, reset, or use the menu for instructions. 
  The Shape and ShapeFields classes helped in handling the coordinates of the pieces when rotating by 
  storing such values in 2D arrays. Similarly, each shape utilized 2D arrays to properly update the 
  coordinates and adjust accordingly with what turn they were on. Overall, the private states are 
  encapsulated when needed. Though I needed some variables to be static or public in the scope of 
  neighboring classes, I kept certain methods and variables private to each class to prevent any
  exterior alterations. If given the chance, the main change I would make is the structure of my
  inheritance between Shape and each of the different shape classes with the rotateLeft method.
  My current structure requires the instantiation of the Shape class, so I would have to remove this
  and change the way I updated the shape coordinates when rotating. In this manner, I could then change
  the Shape class into an abstract class that is extended from each shape class.


========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.
